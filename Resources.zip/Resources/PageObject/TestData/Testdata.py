# Home Page Test Data
standardUsername = "standard_user"
password = "secret_sauce"

# CYI Page Test Data
firstName = "Mohamad"
lastName = "Arga"
zip = "43122"