import pandas as pd

class ExcelLibrary:
    def read_test_data(self, file_path):
        df = pd.read_excel('C:/Users/sekumarp/PycharmProjects/Robotproject/TestData/LoginData.xlsx')
        return df.to_dict(orient='records')
